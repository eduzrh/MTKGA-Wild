from ..BaseModule import BaseModule

class Strategy(BaseModule):

	def __init__(self):
		super(Strategy, self).__init__()