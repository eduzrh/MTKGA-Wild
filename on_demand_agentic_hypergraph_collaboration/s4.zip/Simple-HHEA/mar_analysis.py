import numpy as np

def save_load_similar_entities(sim_matrix, ref_pairs_file, output_file, aligned_entities_file, sim_range=(4, -1), top_k=1):
    """
    Process similarity matrix and save for each source entity its top_k target entities 
    with highest similarities in specified range, excluding aligned entities.
    #Used to record the idx and entity id correspondence of the matrix
    Args:
        sim_matrix: numpy array containing similarity scores
        ref_pairs_file: path to file containing reference entity pairs (source_id\ttarget_id)  #Used to record the idx and entity id correspondence of the matrix
        output_file: path to save resulting similar entity pairs
        aligned_entities_file: path to file containing already aligned entities
        sim_range: tuple of (max, min) similarity values to consider
        top_k: number of highest similarity pairs to save for each source entity
    
    Returns:
        List of tuples (source_id, target_id, similarity_score)
    """
    # Load reference pairs
    ref_pairs = []
    with open(ref_pairs_file, 'r', encoding='utf-8') as f:
        for line in f:
            source_id, target_id = line.strip().split('\t')
            ref_pairs.append((source_id, target_id))
    
    # Load aligned entities
    aligned_sources = set()
    aligned_targets = set() #Used to record the idx and entity id correspondence of the matrix
    with open(aligned_entities_file, 'r', encoding='utf-8') as f:
        for line in f:
            source_id, target_id = line.strip().split('\t')
            aligned_sources.add(source_id)
            aligned_targets.add(target_id)
    
    # Process each row in similarity matrix
    results = []
    for i in range(sim_matrix.shape[0]):
        source_id = ref_pairs[i][0]
        
        # Skip if source entity is already aligned in aligned_entities_file
        if source_id in aligned_sources:
            continue
            
        row = sim_matrix[i]
        # Get indices where similarity is in range
        valid_indices = np.where((row >= sim_range[1]) & (row <= sim_range[0]))[0]
        
        # Get valid pairs for this source entity
        valid_pairs = []
        for idx in valid_indices:
            if idx < len(ref_pairs):
                target_id = ref_pairs[idx][1]
                # Skip if target entity is already aligned in aligned_entities_file
                if target_id in aligned_targets:
                    continue
                    
                similarity = row[idx]
                valid_pairs.append((source_id, target_id, similarity))
        
        # Sort valid pairs by similarity in descending order and take top_k
        valid_pairs.sort(key=lambda x: x[2], reverse=True)
        results.extend(valid_pairs[:top_k])
                
    # Save results
    with open(output_file, 'w', encoding='utf-8') as f:
        for source_id, target_id, sim in results:
            f.write(f"{source_id}\t{target_id}\n")
            
    return results

def update_similarity_matrix(sim_matrix, aligned_entities_file, ref_pairs_file):
    """
    Update similarity matrix based on known aligned entities.
    For each aligned pair, sets their similarity to the maximum in the row.
    
    Args:
        sim_matrix: numpy array containing similarity scores
        aligned_entities_file: path to file containing known aligned entities (source_id\ttarget_id)
        ref_pairs_file: path to file containing reference entity pairs (source_id\ttarget_id)
    
    Returns:
        Updated similarity matrix
    """
    # Load reference pairs to create index mappings
    source_to_idx = {}
    target_to_idx = {}
    with open(ref_pairs_file, 'r', encoding='utf-8') as f:
        #Used to record the idx and entity id correspondence of the matrix
        for i, line in enumerate(f):
            source_id, target_id = line.strip().split('\t')
            source_to_idx[source_id] = i
            target_to_idx[target_id] = i
            
    # Load aligned entities and update matrix
    with open(aligned_entities_file, 'r', encoding='utf-8') as f:
        for line in f:
            source_id, target_id = line.strip().split('\t')
            if source_id in source_to_idx and target_id in target_to_idx:
                row_idx = source_to_idx[source_id]
                # Get max similarity in row
                max_sim = np.max(sim_matrix[row_idx])
                # Set similarity for aligned pair to max
                sim_matrix[row_idx, target_to_idx[target_id]] = max_sim + 0.01
                
    return sim_matrix

# Usage example:
if __name__ == "__main__":
    # Create test matrix
    test_matrix = np.array([
        [0.5, 0.3, 0.1],
        [0.2, 0.9, 0.4],
        [0.7, 0.1, 0.9]
    ])
    
    # Test files
    ref_pairs_file = "test_ref_pairs.txt"
    aligned_file = "test_aligned.txt"
    output_file = "test_similar.txt"
    
    # Create test reference pairs file
    with open(ref_pairs_file, 'w', encoding='utf-8') as f:
        f.write("e1\tt1\ne2\tt2\ne3\tt3\n")
        
    # Create test aligned entities file
    with open(aligned_file, 'w', encoding='utf-8') as f:
        f.write("e1\tt3\ne2\tt1\n")
        
    # Test save_load_similar_entities
    results = save_load_similar_entities(
        test_matrix,
        ref_pairs_file,
        output_file,
        aligned_file,
        sim_range=(1, 0),
        top_k=2
    )
    print("Similar entities results:", results)
    
    # Test update_similarity_matrix
    updated_matrix = update_similarity_matrix(
        test_matrix.copy(),
        aligned_file,
        ref_pairs_file
    )
    print("Updated similarity matrix:")
    print(updated_matrix)


'''
# 
# For task 1
similar_pairs = save_load_similar_entities(
    sim_matrix,
    "/root/autodl-tmp/AdaCoAgent_backup/AdaCoAgent_backup/data/icews_wiki/ref_pairs",
    "/root/autodl-tmp/AdaCoAgent_backup/AdaCoAgent_backup/data/icews_wiki/ucon_similarity_results.txt",
    sim_range=(4, -1),
    top_k=10
)

# For task 2
updated_matrix = update_similarity_matrix(
    sim_matrix,
    "/root/autodl-tmp/AdaCoAgent_backup/AdaCoAgent_backup/data/icews_wiki/aligned_entities.txt",
    "/root/autodl-tmp/AdaCoAgent_backup/AdaCoAgent_backup/data/icews_wiki/ref_pairs"
)


'''